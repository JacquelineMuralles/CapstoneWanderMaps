package com.teksystems22.wandermaps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WandermapsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WandermapsApplication.class, args);
	}

}
