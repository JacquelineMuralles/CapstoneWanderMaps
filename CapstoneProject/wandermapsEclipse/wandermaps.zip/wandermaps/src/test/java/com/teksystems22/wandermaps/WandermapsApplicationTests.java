package com.teksystems22.wandermaps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WandermapsApplicationTests {

	@Test
	void contextLoads() {
	}

}
